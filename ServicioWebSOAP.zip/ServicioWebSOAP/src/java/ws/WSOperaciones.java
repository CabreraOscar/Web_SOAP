/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author oscar
 */
@WebService(serviceName = "WSOperaciones")
public class WSOperaciones {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "login")
    public boolean login(@WebParam(name = "user") String user, @WebParam(name = "contrasena") String contrasena) {
        if(user.equals("Oscar")&& contrasena.equals("Oscar123")){
         
        return true;
    }else{
    return false;
  }   
    }  

    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "procesapago")
    public int procesapago(@WebParam(name = "totalpagar") int totalpagar, @WebParam(name = "pago") int pago) {
        if(pago>=totalpagar){
            return pago-totalpagar;
        }else{
          return -1;  
        }
    }

}    
    
    
