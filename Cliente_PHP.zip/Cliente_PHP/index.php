
        <?php
        //crear cliente 
        //pasamos la url swsl
        $cliente =new SoapClient('http://localhost:8080/ServicioWebSOAP/WSOperaciones?WSDL');
     
        //utilizar metodo
        $resultado_pago=$cliente->procesapago([
            
            "totalpagar"=>1000,
            "pago"=>100
            
        ])->return;
        
        if($resultado_pago>=0){
            echo 'Pago realizado';
        }else{
            echo 'Dinero insuficiente';
        }
        
          $resultadologin =$cliente->login([
            
            "user"=>"Oscar",
            "contrasena"=>"Oscar123"
            
        ])->return;
        
        if($resultadologin){
            echo '  Acceso concedido';
        }else{
            echo '  Acceso denegado';
        }
        

