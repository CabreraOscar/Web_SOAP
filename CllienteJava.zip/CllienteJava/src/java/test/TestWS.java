/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import ws.WSOperaciones;
import ws.WSOperaciones_Service;

/**
 *
 * @author oscar
 */
public class TestWS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        WSOperaciones_Service servicio= new WSOperaciones_Service();
        WSOperaciones cliente= servicio.getWSOperacionesPort();
         if(cliente.login("Oscar", "Oscar123")){
             System.out.println("Credenciales correctas");
         }else{
             System.out.println("Credenciales incorrectas");
         }
        System.out.println(cliente.procesapago(50, 500));
    }
    
}
